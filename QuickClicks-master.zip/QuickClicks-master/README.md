# QuickClicks
Android application to access many application in one application.
